import React, { useEffect, useState, useRef } from "react";
import "./DialingScreen.css"; // Import a separate CSS file for custom styles

const Dialer = () => {
  const [recording, setRecording] = useState(false); // State to indicate recording status
  const [userId, setUserId] = useState("Loading..."); // State to hold user ID
  const [audioUrl, setAudioUrl] = useState(""); // State to hold audio URL

  const mediaRecorderRef = useRef(null);
  const recordedChunksRef = useRef([]);

  useEffect(() => {
    // Function to load an external script
    const loadScript = (src, onLoad) => {
      const script = document.createElement("script");
      script.src = src;
      script.onload = onLoad;
      document.body.appendChild(script);
    };

    // Initialize the scripts and ensure that quickstart.js runs after all necessary scripts are loaded
    const initializeScripts = () => {
      loadScript("/jquery.min.js", () => {
        loadScript("/twilio.min.js", () => {
          loadScript("/quickstart.js", () => {
            if (window.initializeQuickstart) {
              window.initializeQuickstart();
            }
          });
        });
      });
    };

    // Fetch the user ID and set it in the state
    const fetchUserId = () => {
      // Replace this with your actual method to fetch the user ID
      const fetchedUserId = "YourUserID";
      setUserId(fetchedUserId);
    };

    // Wait for the component to mount before initializing scripts
    initializeScripts();
    fetchUserId();
  }, []);

  const handleCallButtonClick = () => {
    // Start recording system audio
    startRecording();
  };

  const handleHangupButtonClick = () => {
    stopRecordingAndSaveUrl();
  };

  const startRecording = () => {
    navigator.mediaDevices
      .getDisplayMedia({ audio: true, video: false })
      .then((stream) => {
        mediaRecorderRef.current = new MediaRecorder(stream);

        mediaRecorderRef.current.ondataavailable = (e) => {
          recordedChunksRef.current.push(e.data);
        };

        mediaRecorderRef.current.start();
        setRecording(true);
      })
      .catch((err) => console.error("Error accessing media devices: ", err));
  };

  const stopRecordingAndSaveUrl = () => {
    if (mediaRecorderRef.current && recording) {
      mediaRecorderRef.current.stop();
      setRecording(false);

      mediaRecorderRef.current.onstop = () => {
        const blob = new Blob(recordedChunksRef.current, { type: "audio/wav" });
        const url = URL.createObjectURL(blob);
        setAudioUrl(url);
        recordedChunksRef.current = [];
      };
    }
  };

  const handleDownloadAudioButtonClick = () => {
    if (audioUrl) {
      const link = document.createElement("a");
      link.href = audioUrl;
      link.download = "recorded_audio.wav";
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(audioUrl);
      setAudioUrl(""); // Clear the URL after download
    }
  };

  return (
    <div id="dialing-screen">
      <div id="controls" className="dialer-container">
        <div id="info">
          <h2 className="instructions">Connect Pro</h2>
          <div id="client-name" className="user-info">
            User ID: <span id="user-id">{userId}</span>
          </div>
          <div id="output-selection">
            <label>Speaker Devices:</label>
            <select id="speaker-devices" className="device-list">
              <option value="default">Default Speaker</option>
              {/* Add other device options dynamically */}
            </select>
          </div>
        </div>
        <div id="call-controls">
          <h2 className="instructions">Make a Call:</h2>
          <input
            id="phone-number"
            type="text"
            placeholder="Enter a phone # or client name"
            className="dialer-input"
          />
          <div id="button-group">
            <button
              id="button-call"
              className="dialer-button"
              onClick={handleCallButtonClick}
            >
              Call
            </button>
            <button
              id="button-hangup"
              className="dialer-button"
              onClick={handleHangupButtonClick}
            >
              Hangup
            </button>
            {audioUrl && (
              <button
                id="button-download-audio"
                className="dialer-button"
                onClick={handleDownloadAudioButtonClick}
              >
                Download Audio
              </button>
            )}
          </div>
          <div id="volume-indicators">
            <label>Mic Volume</label>
            <div id="input-volume" className="volume-bar"></div>
            <br />
            <label>Speaker Volume</label>
            <div id="output-volume" className="volume-bar"></div>
          </div>
        </div>
       </div>
    </div>
  );
};

export default Dialer;
