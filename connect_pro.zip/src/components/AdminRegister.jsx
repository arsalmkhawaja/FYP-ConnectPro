import React, { useState } from "react";
import axios from "axios";

const AdminRegister = () => {
  const [formData, setFormData] = useState({
    email: "",
    password: "",
    profileImage: null,
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleFileChange = (e) => {
    setFormData({ ...formData, profileImage: e.target.files[0] });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const formDataObj = new FormData();
    formDataObj.append("email", formData.email);
    formDataObj.append("password", formData.password);
    formDataObj.append("profileImage", formData.profileImage);

    try {
      const response = await axios.post(
        "http://localhost:4000/api/v1/register/admin",
        formDataObj,
        {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        }
      );
      console.log("Admin registered successfully:", response.data);
    } catch (error) {
      console.error("Error registering admin:", error);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <h2>Register as Admin</h2>

      <label>Email:</label>
      <input
        type="email"
        name="email"
        value={formData.email}
        onChange={handleChange}
        required
      />

      <label>Password:</label>
      <input
        type="password"
        name="password"
        value={formData.password}
        onChange={handleChange}
        required
      />

      <label>Profile Image:</label>
      <input type="file" name="profileImage" onChange={handleFileChange} />

      <button type="submit">Register</button>
    </form>
  );
};

export default AdminRegister;
