require("dotenv").config();
require("express-async-errors");

const connectDB = require("./config/db");
const express = require("express");
const cors = require("cors");
const app = express();
const mainRouter = require("./routes/user");
const campaignRouter = require("./routes/campaign_routes"); // Add campaign routes

// Middleware to parse JSON
app.use(express.json());

// Enable Cross-Origin Resource Sharing (CORS)
app.use(cors());

// Routes
app.use("/api/v1", mainRouter);
app.use("/api/v2", campaignRouter); // Use campaign routes for API requests

// Default port set from .env or fallback to 3000
const port = process.env.PORT || 4000;

// Function to start the server
const start = async () => {
  try {
    // Connect to MongoDB
    await connectDB(process.env.MONGO_URI);

    // Start server after successful DB connection
    app.listen(port, () => {
      console.log(`Server is listening on port ${port}`);
    });
  } catch (error) {
    console.log("Error starting the server:", error);
  }
};

// Test route for checking if the server is running
app.get("/", (req, res) => {
  res.send("Server is running");
});

start();
